import { Component, OnInit } from '@angular/core';
import { LoginServiceService } from '../service/login-service.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  name:String;
  constructor(private data: LoginServiceService) { }
  ngOnInit() {
    this.getUserName();
  }
  getUserName(){
    this.data.currentMessage.subscribe(name => this.name = name)
  }
}
